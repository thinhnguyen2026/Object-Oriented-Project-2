import java.util.Scanner;

public class Driver {
    private static Location currLocation;
    private static ContainerItem myInventory = new ContainerItem("Backpack", "Container", "A sturdy backpack.");
    
    public static void main(String[] args) {
        createWorld();
       
        Scanner myObj = new Scanner(System.in);

        System.out.println("Welcome to my Haunted Thanksgiving Game!");
        while (true){
            System.out.print("Enter a command: ");
            String command = myObj.nextLine();
            String[] commandParts = command.split(" ");

            switch (commandParts[0].toLowerCase()) {
                case "quit":
                    System.out.println("Exiting the game...");
                    myObj.close();
                    return;
                    
                case "look":
                    System.out.println(currLocation.getName() + " - " + currLocation.getDescription() + " currently has the following items:");
                    for (int i = 0; i < currLocation.numItems(); i++) {
                        System.out.println("+ " + currLocation.getItem(i).getName());
                    }
                    break;

                case "examine":
                    if (commandParts.length > 1) {
                        Item item = currLocation.getItem(commandParts[1]);
                        if (item != null) {
                            System.out.println(item.toString());
                        } else {
                            System.out.println("Cannot find that item");
                        }
                    } else {
                        System.out.println("Please specify an item to examine.");
                    }
                    break;

                case "go": 
                    if(commandParts.length == 1) {
                        System.out.println("You did not tell me a direction that you want to move in");
                    } 
                    else {
                        String direction = commandParts[1].toLowerCase();
                        if(direction.equals("north")||direction.equals("south")||direction.equals("west")||direction.equals("east")){
                            if(currLocation.canMove(direction)) {
                                currLocation = currLocation.getLocation(direction);
                            } else {
                                System.out.println("I am unable to move in that direction");
                            }
                        } 
                        else {
                            System.out.println("Please enter a valid direction");
                        }
                    }
                    break;
                
                case "inventory":
                    System.out.println(myInventory);
				    break;

                case "take":
                    if (commandParts.length > 1) {
                        if (currLocation.hasItem(commandParts[1])) {
                            Item item = currLocation.getItem(commandParts[1]);
                            myInventory.addItem(item);
                            currLocation.removeItem(commandParts[1]);
                            System.out.println("You took the " + commandParts[1]);
                        } else {
                            System.out.println("This location does not have this item");
                        }
                    } else {
                        System.out.println("Please enter a valid item");
                    }
                    break;

                case "drop":
                if (commandParts.length > 1) {
                    if (myInventory.hasItem(commandParts[1])) {
                        Item item = myInventory.removeItem(commandParts[1]);
                        currLocation.addItem(item);  
                        System.out.println("You dropped the " + commandParts[1]);
                    } else {
                        System.out.println("You do not have this item in your inventory");
                    }
                } else {
                    System.out.println("Please enter a valid item");
                }
                break;
                
                case "help":
                    printHelp();
                    break;

                default:
                    System.out.println("I don't know how to do that, type 'help' for a list of commands");
                    break;
            }
        }
    }

    public static void createWorld(){
        Location kitchen = new Location("Kitchen","A dark and damp kitchen with a flickering light");
        Location hallway = new Location("Hallway","There are smears of gravy on the walls");
        Location bedroom = new Location("Bedroom","A messy bedroom with a lot of dust and cobwebs");
        Location laundry = new Location("Laundry","A faint gobbling is heard over the sound of a humming dryer that was left on");

        kitchen.connect("north", hallway);
        hallway.connect("south", kitchen);
        kitchen.connect("west", bedroom);
        bedroom.connect("east", kitchen);
        kitchen.connect("south", laundry);
        laundry.connect("north", kitchen);

        kitchen.addItem(new Item("Knife", "Weapon", "It's sharp and pointy"));
        kitchen.addItem(new Item("Turkey", "Food", "It's cold and now but delicious"));
        bedroom.addItem(new Item("Lamp","Item","An old lamp with a bit dust" ));
        laundry.addItem(new Item("Detergent","Item","A dirty detergent bottle with blood on the surface"));
        hallway.addItem(new Item("Plate","Item","A dirty plate with one corner broken"));

        currLocation = hallway;
    }

    public static void printHelp() {
        System.out.println("'GO' command moves to the direction including north, south, west and east");
        System.out.println("'LOOK' command prints items that are found at that location currently" );
        System.out.println("'EXAMINE' command prints a description of surroundings items");
        System.out.println("'TAKE' command takes an item from the current location and put it into inventory");
        System.out.println("'DROP' command drops an item from inventory and put it at the current location");
        System.out.println("'INVENTORY' command lists the objects that you already took");
        System.out.println("'QUIT' command exits the game");
        System.out.println("'HELP' command gives you specific command descriptions to help you run the game");
    }
}

